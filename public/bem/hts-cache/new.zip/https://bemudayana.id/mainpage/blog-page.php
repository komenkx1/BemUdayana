<!DOCTYPE html>
    <html lang="en">

<head>
    <meta charset="utf-8"/>
    <title>Blog | BEM PM UDAYANA - Reparasi Cita</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Shreethemes" name="author" />
    <!-- favicon tab browser -->
    <link rel="shortcut icon" href="blog_images/icon.png">

    <!-- Bootstrap -->
    <link href="blog_css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

    <!-- Icons -->
    <link href="blog_css/materialdesignicons.min.css" rel="stylesheet" type="text/css"/>

    <!-- Magnific -->
    <link href="blog_css/magnific-popup.css" rel="stylesheet" type="text/css"/>

    <!-- Swiper -->
    <link href="blog_css/swiper.min.css" rel="stylesheet" type="text/css"/>

    <!-- Main Css -->
    <link href="blog_css/style.css" rel="stylesheet" type="text/css"/>
    
    <!-- Main Css -->
    <link href="../bem_css/style.css" rel="stylesheet" type="text/css"/>

    <!-- CDN and CDNJS for Counter Up-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="https://kit.fontawesome.com/846fb5ea74.js" crossorigin="anonymous"></script>
    
    

</head>

<body>
  
    <!-- Navbar Start -->
    <header id="topnav" class="defaultscroll sticky">
        <div class="container">

        <!-- Logo container-->
        <div>
            <a class="logo" href="bem_index.php">
                <img src="blog_images/logo-dark.png" class="l-dark" height="50" alt="">
                <img src="blog_images/logo-light.png" class="l-light" height="50" alt="">
            </a>
        </div>
        <!-- End Logo container-->

        <div class="menu-extras">
            <div class="menu-item">

                <!-- Mobile menu toggle-->
                <a class="navbar-toggle">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
                <!-- End mobile menu toggle-->

            </div>
        </div>

        <!-- Navigation Menu-->
        <div id="navigation">
            <ul class="navigation-menu nav-light">
                <li><a href="bemudayana.id">Beranda</a></li>
                <li><a href="../sdu.html">Student Day</a></li>
                <li><a href="../tentang.html">Tentang</a></li>
                <li><a href="../program_kerja.html">Program Kerja</a></li>
                <li><a href="blog-page.php">Blog</a></li>
                <li class="has-submenu">
                    <a href="javascript:void(0)">Informasi</a><span class="menu-arrow"></span>
                    <ul class="submenu">
                        <li><a href="../perekrutan_terbuka.html">Open Recruitment Big Events</a></li>
                        <li><a href="../lembaga_mahasiswa.html">Lembaga Mahasiswa</a></li>
                        <li><a href="../ukm.html">UKM</a></li>
                        <li><a href="../paguyuban.html">Paguyuban dan Forum Agama</a></li>
                        <li><a href="../asrama.html">Info Asrama</a></li>
                    </ul>
                </li>
                <li><a href="../kontak.html">Kontak</a></li>
            </ul>
        </div><!--end navigation-->
        </div><!--end container-->
    </header><!--end header-->
    <!-- Navbar End -->
    
    <!-- START BLOG -->
    
    <!-- Hero Start -->
    <section class="swiper-slider-hero position-relative d-block vh-100" id="home">
        <div class="swiper-container swiper-container-initialized swiper-container-horizontal">
                <div class="swiper-slide d-flex align-items-center overflow-hidden">
                    <div class="slide-inner slide-bg-image d-flex align-items-center" style="background: url(&quot;blog_images/red-bg.png&quot;) center center / cover; height: 100%;" data-background="blog_images/red-bg.png">
                        <div class="container">
                            <div class="row pt-md-5 mt-lg-0">
                                <div class="col-12">
                                    <div class="title-heading">
                                    <h1 href="" class="typewrite heading text-white font-weight-bold mb-4 text-center" data-period="2000" data-type="[ &quot;Portal Informasi Kegiatan Kemahasiswaan.&quot;, &quot;Portal Perekrutan Terbuka.&quot;, &quot;BEM PM Universitas Udayana.&quot;, &quot;Reparasi Cita Udayana.&quot; ]"><span class="wrap">Portal Perekrutan Terbuka.</span></h1>
                                        <!-- <h1 class="heading text-white font-weight-bold mb-4">Portal Informasi Berita, <br>Pengumuman serta Kegiatan Kemahasiswaan di Lingkungan Universitas Udayana</h1>
                                        <p class="para-desc text-white-50">"Bersama Ciptakan Karsa dalam Semangat Reparasi Cita untuk Udayana dan Indonesia"</p> -->
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div><!--end container-->
               
                </div> <!-- end swiper-slide -->
            <!--end container-->
        </div><span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div></section>
    <!-- Hero End -->
    <!-- Blog Content -->
    <!-- Page Content -->
  <div class="container">
<h1 class="my-4">Tulisan kami :</h1>
<div class="row">
              
            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2 mb-4">
                        <div class="card h-100 blog-post shadow rounded position-relative overflow-hidden" style="background-color:white;">
                            <div class="blog-img overflow-hidden position-relative">
                                <img src="../admin.bemudayana.id/dashboard/dist/assets/img/S__21094851.jpg"  class="img-fluid" alt="">
                                <div class="overlay bg-dark"></div>
                                <div class="d-flex author-desc align-items-center">
                                    <img src="../bem_images/icon.png" class="img-fluid avatar avatar-md-sm rounded-pill mr-2 shadow" alt="">
                                    <div class="author">
                                        <a class="text-white h6 name">BEM PM Udayana</a><p class="text-white-50 small mb-0">November 15, 2020 </p>
                                    </div>
                                </div>
                            </div>
                            <div class="position-relative">
                                <div class="shape overflow-hidden text-white">
                                    <svg viewBox="0 0 2880 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M720 125L2160 0H2880V250H0V125H720Z" fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                            <div class="blog-content p-4">
                                <h5 class="title text-dark">Info KKN-PPM Universitas Udayana Periode XXII Januari - Maret 2021</h5>
                                <p class="text-muted item">Informasi mengenai pelaksanaan KKN-PPM Universitas Udayana Periode XXII Januari - Maret 2021</p>

                                <div class="post-meta d-flex justify-content-between pt-3 border-top">
                                    <a href="/mainpage/blogposts/single-page.php?slug=Info-KKN-PPM-Universitas-Udayana-Periode-XXII-Januari---Maret-2021" class="text-dark read">Baca Selanjutnya &rarr;</a>
                                </div>
                            </div>
                        </div><!--end post-->
                    </div><!--end col-->
                    
              
            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2 mb-4">
                        <div class="card h-100 blog-post shadow rounded position-relative overflow-hidden" style="background-color:white;">
                            <div class="blog-img overflow-hidden position-relative">
                                <img src="../admin.bemudayana.id/dashboard/dist/assets/img/wisuda bulan ini-01.jpg"  class="img-fluid" alt="">
                                <div class="overlay bg-dark"></div>
                                <div class="d-flex author-desc align-items-center">
                                    <img src="../bem_images/icon.png" class="img-fluid avatar avatar-md-sm rounded-pill mr-2 shadow" alt="">
                                    <div class="author">
                                        <a class="text-white h6 name">BEM PM Udayana</a><p class="text-white-50 small mb-0">October 12, 2020 </p>
                                    </div>
                                </div>
                            </div>
                            <div class="position-relative">
                                <div class="shape overflow-hidden text-white">
                                    <svg viewBox="0 0 2880 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M720 125L2160 0H2880V250H0V125H720Z" fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                            <div class="blog-content p-4">
                                <h5 class="title text-dark">[Info Pengambilan Toga Wisuda Universitas Udayana Ke-138]⁣</h5>
                                <p class="text-muted item">Pesyaratan dan tata cara pengambilan toga wisuda Universitas Udayana ke-138</p>

                                <div class="post-meta d-flex justify-content-between pt-3 border-top">
                                    <a href="/mainpage/blogposts/single-page.php?slug=-Info-Pengambilan-Toga-Wisuda-Universitas-Udayana-Ke-138-" class="text-dark read">Baca Selanjutnya &rarr;</a>
                                </div>
                            </div>
                        </div><!--end post-->
                    </div><!--end col-->
                    
              
            <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2 mb-4">
                        <div class="card h-100 blog-post shadow rounded position-relative overflow-hidden" style="background-color:white;">
                            <div class="blog-img overflow-hidden position-relative">
                                <img src="../admin.bemudayana.id/dashboard/dist/assets/img/jembud 3-01.jpg"  class="img-fluid" alt="">
                                <div class="overlay bg-dark"></div>
                                <div class="d-flex author-desc align-items-center">
                                    <img src="../bem_images/icon.png" class="img-fluid avatar avatar-md-sm rounded-pill mr-2 shadow" alt="">
                                    <div class="author">
                                        <a class="text-white h6 name">BEM PM Udayana</a><p class="text-white-50 small mb-0">October 20, 2020 </p>
                                    </div>
                                </div>
                            </div>
                            <div class="position-relative">
                                <div class="shape overflow-hidden text-white">
                                    <svg viewBox="0 0 2880 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M720 125L2160 0H2880V250H0V125H720Z" fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                            <div class="blog-content p-4">
                                <h5 class="title text-dark">Esensi Budaya Bercocok Tanam Masyarakat Bali Sejak Masa Lampau Hingga Menjadi Concern Baru di Era New Normal</h5>
                                <p class="text-muted item">Ketika pandemi melanda Bali dan membuat pariwisata merosot, wacana lama kembali dibahas, Bali sebaiknya kembali menggunakan sektor pertanian menjadi penopang utama dalam pembangunan ekonominya. Bali terlalu fokus pada sektor pariwisata dan mengabaikan sektor pertanian sebagai tumpuannya. Lalu apakah masyarakat Bali sebaiknya kembali kepada budaya terdahulunya untuk bertumpu pada sektor pertanian?</p>

                                <div class="post-meta d-flex justify-content-between pt-3 border-top">
                                    <a href="/mainpage/blogposts/single-page.php?slug=Esensi-Budaya-Bercocok-Tanam-Masyarakat-Bali-Sejak-Masa-Lampau-Hingga-Menjadi-Concern-Baru-di-Era-New-Normal" class="text-dark read">Baca Selanjutnya &rarr;</a>
                                </div>
                            </div>
                        </div><!--end post-->
                    </div><!--end col-->
                    
                        </div>
    </div>
    
    
    <div class="text-center">
        <ul class="pagination justify-content-center">
            <li class='page-item active'><a class='page-link' href='#'>1</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=2'>2</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=3'>3</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=4'>4</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=5'>5</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=6'>6</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=7'>7</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=8'>8</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=9'>9</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=10'>10</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=11'>11</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=12'>12</a></li><li class='page-item' align='center'><a class='page-link' href='blog-page.php?halaman=13'>13</a></li>        </ul>
    </div>
    
    <!-- Footer Start -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                    <a class="logo-footer" href="#">
                        <img src="blog_images/logo-light.png" height="40" alt="">
                    </a>
                    <p class="mt-1">"Bersama Ciptakan Karsa dalam Semangat Reparasi Cita untuk Udayana dan Indonesia"</p>
                </div>

                <div class="col-lg-4 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Sekretariat Kami :</h5>
                    <p>Jalan Dr. Goris No. 10, Student Center Lt. 2, Denpasar, Bali, Indonesia<p>
                </div>

                <div class="col-lg-4 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Kontak :</h5>
                    <ul class="list-unstyled footer-list mt-2">
                        <li><i data-feather="mail" class="fea icon-sm mr-2"></i><a href="mailto:contact@bemudayana.id" class="text-foot">contact@bemudayana.id</a></li>
                        <li><i data-feather="phone" class="fea icon-sm mr-2"></i><a href="tel:+6281338955721" class="text-foot">081 338 955 721</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Sosial Media</h5>
                    <ul class="list-unstyled footer-list mt-2">
                        <ul class="list-unstyled social-icon social mb-0">
                            <li class="list-inline-item"><a href="https://www.instagram.com/bem_udayana/?hl=id" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://twitter.com/BEM_Udayana" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://www.youtube.com/channel/UCXb4WEhsHyKtMdqPaKJ4okQ" class="rounded"><i data-feather="youtube" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://open.spotify.com/show/4yP3a4QR1VZ2O1eKSrpNdb?si=MKF2hnCIQ8OQN7BYX2UoNA" class="rounded"><i class="fa fa-spotify" class="fea icon-sm fea-social"></i></a></li>
                        </ul>
                    </ul>
                </div>
            </div>
        </div><!--end container-->
    </footer><!--end footer-->
    <!-- Footer End -->

    <!--Footer Bar-->
    <footer class="footer footer-bar">
        <div class="container text-center">
            <p class="mb-0" style="text-align: center; color: yellow;">© 2020 KOMINFO BEM PM UDAYANA</p>
        </div>
    </footer><!--end footer-->
    <!-- Footer Bar End -->

    <!-- Back to top -->
    <a href="#" class="back-to-top rounded text-center" id="back-to-top">
    <i class="fa fa-arrow-up" aria-hidden="true"></i></i>
    </a>
    <!-- Back to top -->

    <!-- Javascript -->
    <!-- Java Script Pop Out-->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

    <!-- End of JavaScript Pop Out-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <script src="blog_js/jquery.min.js"></script>
    <script src="blog_js/bootstrap.bundle.min.js"></script>

    <!-- Feather icon -->
    <script src="blog_js/feather.min.js"></script>

    <!-- Magnific Popup -->
    <script src="blog_js/jquery.magnific-popup.min.js"></script>
    <script src="blog_js/magnific.init.js"></script>
    <script src="blog_js/isotope.js"></script>
    <script src="blog_js/portfolio.init.js"></script>

    <!-- Swiper -->
    <script src="blog_js/swiper.min.js"></script>
    <script src="blog_js/swiper.init.js"></script>

    <!-- Main Js -->
    <script src="blog_js/app.js"></script>

    <!--Counter-->
    <script src="blog_js/counter.init.js"></script>

    <!-- Typewriter -->
    <script>
    var TxtType = function(el, toRotate, period) {
        this.toRotate = toRotate;
        this.el = el;
        this.loopNum = 0;
        this.period = parseInt(period, 10) || 2000;
        this.txt = '';
        this.tick();
        this.isDeleting = false;
    };

    TxtType.prototype.tick = function() {
        var i = this.loopNum % this.toRotate.length;
        var fullTxt = this.toRotate[i];

        if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
        } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
        }

        this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

        var that = this;
        var delta = 200 - Math.random() * 100;

        if (this.isDeleting) { delta /= 2; }

        if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
        } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 500;
        }

        setTimeout(function() {
        that.tick();
        }, delta);
    };

    window.onload = function() {
        var elements = document.getElementsByClassName('typewrite');
        for (var i=0; i<elements.length; i++) {
            var toRotate = elements[i].getAttribute('data-type');
            var period = elements[i].getAttribute('data-period');
            if (toRotate) {
              new TxtType(elements[i], JSON.parse(toRotate), period);
            }
        }
        // INJECT CSS
        var css = document.createElement("style");
        css.type = "text/css";
        css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
        document.body.appendChild(css);
    };
    </script>
    
    <!--Read More -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(function() {

        $('.item').each(function(event) {
            var max_length = 100;

            if ($(this).html().length > max_length) {

                var short_content = $(this).html().substr(0, max_length);
                var long_content = $(this).html().substr(max_length);

                $(this).html(short_content +
                    '<a href="#" class="read_more">...Read More</a>' +
                    '<span class="more_text" style="display:none;">' + long_content + '</span>');

                $(this).find('a.read_more').click(function(event) {

                    event.preventDefault();
                    $(this).hide();
                    $(this).parents('.item').find('.more_text').show();

                });

            }

        });


    });
</script>


</body>

</html>
