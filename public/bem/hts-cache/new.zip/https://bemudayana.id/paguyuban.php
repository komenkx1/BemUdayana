
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8"/>
    <title>BEM PM UDAYANA - Reparasi Cita</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Shreethemes" name="author" />

    <!-- favicon tab browser -->
    <link rel="shortcut icon" href="bem_images/icon.png">

    <!-- Bootstrap -->
    <link href="bem_css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

    <!-- Icons -->
    <link href="bem_css/materialdesignicons.min.css" rel="stylesheet" type="text/css"/>

    <!-- Magnific -->
    <link href="bem_css/magnific-popup.css" rel="stylesheet" type="text/css"/>

    <!-- Main Css -->
    <link href="bem_css/style.css" rel="stylesheet" type="text/css"/>

    <!-- Font Css -->
    <link href="webfontkit/stylesheet.css" rel="stylesheet" type="text/css"/>

    <!-- Animation Css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>

    <!-- CDN and CDNJS for Counter Up-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="https://kit.fontawesome.com/846fb5ea74.js" crossorigin="anonymous"></script>

    <!-- Untuk Preloader -->
    <script src="http://code.jquery.com/jquery-2.2.1.min.js"></script>
    <style type="text/css">
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background-color: #fff;
        }
        .preloader .loading {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%,-50%);
            font: 14px arial;
        }
    </style>

</head>

<body>
    <!-- LOADER -->
    <div class="preloader">
        <div class="loading">
            <img src="bem_images/loader-bem-fix.gif" width="80">
            <p>Harap Tunggu</p>
        </div>
    </div>
    <!-- END LOADER -->
    
    <!-- Navbar Start -->
    <header id="topnav" class="defaultscroll sticky">
        <div class="container">

        <!-- Logo container-->
        <div>
            <a class="logo" href="bem_index.php">
                <img src="bem_images/logo-light.png" class="l-dark" height="50" alt="">
                <img src="bem_images/logo-dark.png" class="l-light" height="50" alt="">
            </a>
        </div>
        <!-- End Logo container-->

        <div class="menu-extras">
            <div class="menu-item">

                <!-- Mobile menu toggle-->
                <a class="navbar-toggle">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
                <!-- End mobile menu toggle-->

            </div>
        </div>

        <!-- Navigation Menu-->
        <div id="navigation">
            <ul class="navigation-menu nav-light">
                <li><a href="bem_index.php">Beranda</a></li> 
                <li class="has-submenu">
                    <a href="javascript:void(0)">Tentang</a><span class="menu-arrow"></span>
                    <ul class="submenu">
                        <li><a href="tentang.html">Fungsionaris</a></li>
                        <li><a href="program_kerja.php">Program Kerja</a></li>
                        <li><a href="kontak.html">Kontak</a></li>
                    </ul>
                </li>
                <li><a href="mainpage/blog-page.php">Blog</a></li>
                <li class="has-submenu">
                    <a href="javascript:void(0)">Informasi</a><span class="menu-arrow"></span>
                    <ul class="submenu">
                        <li><a href="perekrutan_terbuka.html">Open Recruitment Big Events</a></li>
                        <li><a href="lembaga_mahasiswa.php">Lembaga Mahasiswa</a></li>
                        <li><a href="ukm.php">UKM</a></li>
                        <li><a href="paguyuban.php">Paguyuban dan Forum Agama</a></li>
                        <li><a href="asrama.html">Info Asrama</a></li>
                    </ul>
                </li>
                <li><a href="https://studentday.bemudayana.id/">Student Day</a></li>
            </ul>
        </div><!--end navigation-->
        </div><!--end container-->
    </header><!--end header-->
    <!-- Navbar End -->

    <!-- Hero Start -->
    <section class="position-relative d-block vh-100" id="home">
        <div class="slide-inner slide-bg-image d-flex align-items-center slider-lembaga" style="background: center; height: 100%; background-color:#d7d3c1;">
            <div class="container">
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="title-heading text-center">
                        <p class="heading animate__animated animate__fadeInLeft" style="margin-top:60px">Paguyuban dan Forum Agama</p>
                        <p class="heading animate__animated animate__fadeInLeft animate__slow">Universitas Udayana</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero End -->

    <!-- START LEMBAGA -->
    <section class="section" style="background-color: #E0E0E0;">
    <div class="container">
        <div class="row card-lembaga" style="margin-top: -200px;">

             

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/sasak.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Komoenitas Mahasiswa Sasak</p>
                        <a href="paguyuban_detail.php?id=1" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/islam.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Forum Persatuan Mahasiswa Islam</p>
                        <a href="paguyuban_detail.php?id=2" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/jawa.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Gajayana (Keluaraga Jawa Udayana)</p>
                        <a href="paguyuban_detail.php?id=3" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/kmk.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Keluarga Mahasiswa Katolik St.Albertus Agung Universitas Udayana</p>
                        <a href="paguyuban_detail.php?id=4" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/pmb.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Perhimpunan Mahasiswa Bima Dompu- Bali</p>
                        <a href="paguyuban_detail.php?id=5" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/pamanahan.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Paguyuban Mahasiswa Tanah Pasundan</p>
                        <a href="paguyuban_detail.php?id=6" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/fphd.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Forum Persaudaraan Mahasiswa Hindu Dharma Universitas Udayana (GPMHS-Unud)</p>
                        <a href="paguyuban_detail.php?id=7" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/ikmm.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Ikatan Keluarga Seluruh Mahasiswa Minang)</p>
                        <a href="paguyuban_detail.php?id=8" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/a.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Keluarga Besar Mahasiswa Kristen Universitas Udayana</p>
                        <a href="paguyuban_detail.php?id=9" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
            

            <div class="col-sm-3">
                <div class="mt-4 feature-transform text-center shadow position-relative d-block overflow-hidden bg-white rounded">
                    <img src="bem_images/paguyuban/fkmbu.jpg" class="img-fluid" alt="">
                    <div class="content py-3" style="height: 160px">
                        <p style="font-weight: bold;">Forum Keluarga Mahasiswa Buddhis Universitas Udayana</p>
                        <a href="paguyuban_detail.php?id=10" class="text-primary read-more">Selengkapnya <i class="mdi mdi-chevron-right"></i></a>
                    </div>
                </div>
            </div><!--end col-->
            
           
        </div><!--end row-->
    </div><!--end container-->
    </section>
    <!-- END LEMBAGA -->

    <!-- Footer Start -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                    <a class="logo-footer" href="#">
                        <img src="bem_images/logo-light.png" height="40" alt="">
                    </a>
                    <p class="mt-1">"Bersama Ciptakan Karsa dalam Semangat Reparasi Cita untuk Udayana dan Indonesia"</p>
                </div>

                <div class="col-lg-4 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Sekretariat Kami :</h5>
                    <p>Jalan Dr. Goris No. 10, Student Center Lt. 2, Denpasar, Bali, Indonesia<p>
                </div>

                <div class="col-lg-4 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Kontak :</h5>
                    <ul class="list-unstyled footer-list mt-2">
                        <li><i data-feather="mail" class="fea icon-sm mr-2"></i><a href="mailto:contact@bemudayana.id" class="text-foot">contact@bemudayana.id</a></li>
                        <li><i data-feather="phone" class="fea icon-sm mr-2"></i><a href="tel:+6281338955721" class="text-foot">081 338 955 721</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Sosial Media</h5>
                    <ul class="list-unstyled footer-list mt-2">
                        <ul class="list-unstyled social-icon social mb-0">
                            <li class="list-inline-item"><a href="https://www.instagram.com/bem_udayana/?hl=id" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://twitter.com/BEM_Udayana" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://www.youtube.com/channel/UCXb4WEhsHyKtMdqPaKJ4okQ" class="rounded"><i data-feather="youtube" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://open.spotify.com/show/4yP3a4QR1VZ2O1eKSrpNdb?si=MKF2hnCIQ8OQN7BYX2UoNA" class="rounded"><i class="fa fa-spotify" class="fea icon-sm fea-social"></i></a></li>
                        </ul>
                    </ul>
                </div>
            </div>
        </div><!--end container-->
    </footer><!--end footer-->
    <!-- Footer End -->

    <!--Footer Bar-->
    <footer class="footer footer-bar">
        <div class="container text-center">
            <p class="mb-0" style="text-align: center; color: yellow;">© 2020 KOMINFO BEM PM UDAYANA</p>
        </div>
    </footer><!--end footer-->
    <!-- Footer Bar End -->

    <!-- Back to top -->
    <a href="#" class="back-to-top rounded text-center" id="back-to-top">
        <i class="mdi mdi-chevron-up d-block"></i>
    </a>
    <!-- Back to top -->

    <!-- Javascript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <script src="bem_js/jquery.min.js"></script>
    <script src="bem_js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <!-- Feather icon -->
    <script src="bem_js/feather.min.js"></script>

    <!-- Loader -->
    <script>
        $(document).ready(function(){
        $(".preloader").fadeOut();
        })
    </script>

    <!-- Magnific Popup -->
    <script src="bem_js/jquery.magnific-popup.min.js"></script>
    <script src="bem_js/magnific.init.js"></script>
    <script src="bem_js/isotope.js"></script>
    <script src="bem_js/portfolio.init.js"></script>

    <!-- Main Js -->
    <script src="bem_js/app.js"></script>

    <!-- Feather icon -->
    <script src="bem_js/feather.min.js"></script>

    <!-- Swiper -->
    <script src="bem_js/swiper.min.js"></script>
    <script src="bem_js/swiper.init.js"></script>

    <!--Counter-->
    <script src="bem_js/counter.init.js"></script>
</body>
</html>