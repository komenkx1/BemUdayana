
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8"/>
    <title>BEM PM UDAYANA - Reparasi Cita</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Shreethemes" name="author" />

    <!-- favicon tab browser -->
    <link rel="shortcut icon" href="bem_images/icon.png">

    <!-- Bootstrap -->
    <link href="bem_css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

    <!-- Icons -->
    <link href="bem_css/materialdesignicons.min.css" rel="stylesheet" type="text/css"/>

    <!-- Magnific -->
    <link href="bem_css/magnific-popup.css" rel="stylesheet" type="text/css"/>

    <!-- Main Css -->
    <link href="bem_css/style.css" rel="stylesheet" type="text/css"/>

    <!-- Font Css -->
    <link href="webfontkit/stylesheet.css" rel="stylesheet" type="text/css"/>

    <!-- Animation Css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>

    <!-- fullcalendar -->
    <link rel="stylesheet" href="fullcalendar/dist/fullcalendar.min.css">
    <link rel="stylesheet" href="fullcalendar/dist/fullcalendar.print.min.css" media="print">

    <!-- CDN and CDNJS for Counter Up-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="https://kit.fontawesome.com/846fb5ea74.js" crossorigin="anonymous"></script>

    <!-- Untuk Preloader -->
    <script src="http://code.jquery.com/jquery-2.2.1.min.js"></script>
    <style type="text/css">
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background-color: #fff;
        }
        .preloader .loading {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%,-50%);
            font: 14px arial;
        }
    </style>

</head>

<body>
    <!-- LOADER -->
    <div class="preloader">
        <div class="loading">
            <img src="bem_images/loader-bem-fix.gif" width="80">
            <p>Harap Tunggu</p>
        </div>
    </div>
    <!-- END LOADER -->
    
    <!-- Navbar Start -->
    <header id="topnav" class="defaultscroll sticky">
        <div class="container">

        <!-- Logo container-->
        <div>
            <a class="logo" href="bem_index.php">
                <img src="bem_images/logo-light.png" class="l-dark" height="50" alt="">
                <img src="bem_images/logo-dark.png" class="l-light" height="50" alt="">
            </a>
        </div>
        <!-- End Logo container-->

        <div class="menu-extras">
            <div class="menu-item">

                <!-- Mobile menu toggle-->
                <a class="navbar-toggle">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
                <!-- End mobile menu toggle-->

            </div>
        </div>

        <!-- Navigation Menu-->
        <div id="navigation">
            <ul class="navigation-menu nav-light">
                <li><a href="bem_index.php">Beranda</a></li> 
                <li class="has-submenu">
                    <a href="javascript:void(0)">Tentang</a><span class="menu-arrow"></span>
                    <ul class="submenu">
                        <li><a href="tentang.html">Fungsionaris</a></li>
                        <li><a href="program_kerja.php">Program Kerja</a></li>
                        <li><a href="kontak.html">Kontak</a></li>
                    </ul>
                </li>
                <li><a href="mainpage/blog-page.php">Blog</a></li>
                <li class="has-submenu">
                    <a href="javascript:void(0)">Informasi</a><span class="menu-arrow"></span>
                    <ul class="submenu">
                        <li><a href="perekrutan_terbuka.html">Open Recruitment Big Events</a></li>
                        <li><a href="lembaga_mahasiswa.php">Lembaga Mahasiswa</a></li>
                        <li><a href="ukm.php">UKM</a></li>
                        <li><a href="paguyuban.php">Paguyuban dan Forum Agama</a></li>
                        <li><a href="asrama.html">Info Asrama</a></li>
                    </ul>
                </li>
            </ul>
        </div><!--end navigation-->
        </div><!--end container-->
    </header><!--end header-->
    <!-- Navbar End -->

    <!-- Hero Start -->
    <section class="position-relative d-block vh-100" id="home">
        <div class="slide-inner slide-bg-image d-flex align-items-center" style="background: center; height: 100%; background-color:#d7d3c1;">
            <div class="container bem">
                <div class="row mt-4">
                    <div class="col-md-8">
                        <div class="title-heading">
                        <p class="heading animate__animated animate__fadeInLeft" style="margin-top:60px">Badan Eksekutif Mahasiswa (BEM)</p>
                        <p class="heading animate__animated animate__fadeInLeft animate__slow">Pemerintahan Mahasiswa</p>
                        <p class="heading animate__animated animate__fadeInLeft animate__slower">Universitas Udayana 2020</p>
                        <p class="para-desc" style="color:#be5e53; font-family:photograph_signature; font-size:25px">"Bersama Ciptakan Karsa dalam Semangat Reparasi Cita untuk Udayana dan Indonesia"</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <img src="bem_images/a1.png" width="100%" class="align-items-center">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero End -->

    <!-- HOTLINE MAHASISWA -->
    <div style="background-color: #d7d3c1;">
        <section class="ftco-section ftco-services">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-lg-4" style="z-index: 1;">
                        <form action="input_hotline.php" method="POST" class="getaquote-form">
                            <h3 style="font-family:museo700">Hotline Mahasiswa</h3>
                                <div class="wrap">

                                <!--PHP Hotline Status-->
                                                                <!-- End of PHP Hotline Status-->

                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Email, WA atau ID Line" name="email_ht">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Nama" name="nama_ht">
                                    </div>
                                    <div class="form-group">
                                        <textarea cols="30" rows="7" class="form-control" placeholder="Pesan" name="pesan_ht"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Kirim Pesan" class="btn btn-primary py-3 px-5" name="submit">
                                    </div>
                                </div>
                        </form>
                    </div>

                    <!--COUNTER START-->
                    <div class="row col-md margincus" style="margin-top:-20px">
                        <div class="col-1">
                        </div>
                        <div class="col-11 hotline">
                            <p style=" font-family:museo700; color:#be5e53; font-size:50px;">#KuyTanyeAje</p>
                            <p style="font-weight:bold;" class="hotline-desc">Hotline mahasiswa dibuka pada Hari Minggu dan Rabu. Selain lewat website, kalian juga bisa curhat lewat DM Instagram dan Line akun BEM PM Udayana dari pukul 17.00 sampai 19.00 WITA. Jangan lupa sertakan hastag #KuyTanyeAje ya!⁣⁣</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- END HOTLINE MAHASISWA -->

    <!-- Start Features -->
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title mb-4 pb-2">
                        <h6 class="text-muted" style="font-family:museo700">Spirit Utama</h6>
                        <p class="mb-2 reparasi" style="font-family:museo700; font-size: 30px">Reparasi Cita Udayana</p>
                        <p class="mb-0" style="font-family:segoe script; font-size:14px">Cita Karsa, Ruang, dan Karya, Reparasi dari Udayana untuk  Indonesia</p>
                    </div>
                </div><!--end col-->
            </div><!--end row-->

            <div class="row">
                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="feature feature-transition p-4 py-5 shadow rounded text-center" style="background-color: #f3c066">
                        <img src="bem_images/spirit/karsa.svg" class="avatar avatar-small" alt="">
                        <h5 class="title mt-3 museo">Cita Karsa</h5>
                        <p class="">BEM PM menjadi simbol adanya daya dan kekuatan jiwa yang mendorong elemen mahasiswa untuk berkehendak dan bergerak</p>
                    </div>
                </div><!--end col-->

                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="feature feature-transition p-4 py-5 shadow rounded text-center" style="background-color: #f3c066">
                        <img src="bem_images/spirit/ruang.svg" class="avatar avatar-small" alt="">
                        <h5 class="title mt-3 museo">Cita Ruang</h5>
                        <p class="">BEM PM menjadi sebuah wadah untuk bertemu, saling betukar pikiran, dan memastikan ruang itu cukup nyaman menampung banyak entitas dan spektrum</p>
                    </div>
                </div><!--end col-->

                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="feature feature-transition p-4 py-5 shadow rounded text-center" style="background-color: #f3c066">
                        <img src="bem_images/spirit/karya.svg" class="avatar avatar-small" alt="">
                        <h5 class="title mt-3 museo">Cita Karya</h5>
                        <p class="">Menumbuhkan BEM PM sebagai<br> inisiator penciptaan hasil pemikiran<br>dalam bentuk karya<br>yang berkontrbusi nyata</p>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end conatiner-->
    </section><!--end section-->
    <!-- End Features -->

    <!-- VIDEO -->
        <section class="bg-half-170 bg-digital-marketing border-bottom d-table w-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="title-kenal">
                            <h2 class="kenal text-light mb-4 museo">Kenal Lebih Dekat.</h2>
                            <p class="text-white-50 para-desc mb-0">Yuk kenalan lebih dekat dengan BEM PM Universitas Udayana Tahun 2020 di Kabinet Reparasi Cita, supaya bisa sama-sama menuju Udayana dan Indonesia yang lebih maju.</p>
                        </div>
                    </div><!--end col-->

                    <div class="col-md-6 mt-4 mt-sm-0 pt-2 pt-sm-0">
                        <div class="position-relative ml-lg-4">
                            <img src="bem_images/dekat.jpg" class="img-fluid digital-hero rounded-pill" alt="">
                            <div class="play-icon">
                                <a href="https://www.youtube.com/watch?v=H-rNI1nr5vI" class="play-btn video-play-icon">
                                    <i class="mdi mdi-play mdi-24px text-primary rounded-circle bg-primary shadow"></i>
                                </a>
                            </div>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div> <!--end container-->
        </section><!--end section-->
        <div class="position-relative">
            <div class="shape overflow-hidden text-white">
                <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
    <!-- VIDEO End -->

    <!-- START BLOG -->
    <div class="jumbotron jumbotron-fluid" style="background-color: white">
        <div class="container">
            <h1 class="display-4" style="font-family:museo700">Blog Kami</h1>
                <div class="row"> 

                      

                        <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                            <div class=" card h-100 blog-post shadow rounded position-relative overflow-hidden" style="background-color:white;">
                                <div class="blog-img overflow-hidden position-relative">
                                    <img src="admin.bemudayana.id/dashboard/dist/assets/img/S__21094851.jpg" class="img-fluid" alt="">
                                        <div class="overlay bg-dark"></div>
                                        <div class="d-flex author-desc align-items-center">
                                            <img src="bem_images/icon.png" class="img-fluid avatar avatar-md-sm rounded-pill mr-2 shadow" alt="">
                                                <div class="author">
                                                    <a class="text-white h6 name">BEM PM Udayana</a><p class="text-white-50 small mb-0">November 15, 2020 </p>
                                                </div>
                                        </div>
                                </div>
                            <div class="position-relative">
                                <div class="shape overflow-hidden text-white">
                                    <svg viewBox="0 0 2880 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M720 125L2160 0H2880V250H0V125H720Z" fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                            <div class="blog-content p-4 h">
                                <h5 class="title text-dark">Info KKN-PPM Universitas Udayana Periode XXII Januari - Maret 2021</h5>
                                <p class="text-muted item">Informasi mengenai pelaksanaan KKN-PPM Universitas Udayana Periode XXII Januari - Maret 2021</p>

                                <div class="post-meta d-flex justify-content-between pt-3 border-top">
                                    <a href="mainpage/blogposts/single-page.php?slug=Info-KKN-PPM-Universitas-Udayana-Periode-XXII-Januari---Maret-2021" class="text-dark read">Baca Selanjutnya <i class="mdi mdi-chevron-right"></i></a>
                                </div>
                            </div>
                            </div><!--end post-->
                        </div><!--end col-->
                      

                        <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                            <div class=" card h-100 blog-post shadow rounded position-relative overflow-hidden" style="background-color:white;">
                                <div class="blog-img overflow-hidden position-relative">
                                    <img src="admin.bemudayana.id/dashboard/dist/assets/img/wisuda bulan ini-01.jpg" class="img-fluid" alt="">
                                        <div class="overlay bg-dark"></div>
                                        <div class="d-flex author-desc align-items-center">
                                            <img src="bem_images/icon.png" class="img-fluid avatar avatar-md-sm rounded-pill mr-2 shadow" alt="">
                                                <div class="author">
                                                    <a class="text-white h6 name">BEM PM Udayana</a><p class="text-white-50 small mb-0">October 12, 2020 </p>
                                                </div>
                                        </div>
                                </div>
                            <div class="position-relative">
                                <div class="shape overflow-hidden text-white">
                                    <svg viewBox="0 0 2880 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M720 125L2160 0H2880V250H0V125H720Z" fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                            <div class="blog-content p-4 h">
                                <h5 class="title text-dark">[Info Pengambilan Toga Wisuda Universitas Udayana Ke-138]⁣</h5>
                                <p class="text-muted item">Pesyaratan dan tata cara pengambilan toga wisuda Universitas Udayana ke-138</p>

                                <div class="post-meta d-flex justify-content-between pt-3 border-top">
                                    <a href="mainpage/blogposts/single-page.php?slug=-Info-Pengambilan-Toga-Wisuda-Universitas-Udayana-Ke-138-" class="text-dark read">Baca Selanjutnya <i class="mdi mdi-chevron-right"></i></a>
                                </div>
                            </div>
                            </div><!--end post-->
                        </div><!--end col-->
                      

                        <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                            <div class=" card h-100 blog-post shadow rounded position-relative overflow-hidden" style="background-color:white;">
                                <div class="blog-img overflow-hidden position-relative">
                                    <img src="admin.bemudayana.id/dashboard/dist/assets/img/jembud 3-01.jpg" class="img-fluid" alt="">
                                        <div class="overlay bg-dark"></div>
                                        <div class="d-flex author-desc align-items-center">
                                            <img src="bem_images/icon.png" class="img-fluid avatar avatar-md-sm rounded-pill mr-2 shadow" alt="">
                                                <div class="author">
                                                    <a class="text-white h6 name">BEM PM Udayana</a><p class="text-white-50 small mb-0">October 20, 2020 </p>
                                                </div>
                                        </div>
                                </div>
                            <div class="position-relative">
                                <div class="shape overflow-hidden text-white">
                                    <svg viewBox="0 0 2880 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M720 125L2160 0H2880V250H0V125H720Z" fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                            <div class="blog-content p-4 h">
                                <h5 class="title text-dark">Esensi Budaya Bercocok Tanam Masyarakat Bali Sejak Masa Lampau Hingga Menjadi Concern Baru di Era New Normal</h5>
                                <p class="text-muted item">Ketika pandemi melanda Bali dan membuat pariwisata merosot, wacana lama kembali dibahas, Bali sebaiknya kembali menggunakan sektor pertanian menjadi penopang utama dalam pembangunan ekonominya. Bali terlalu fokus pada sektor pariwisata dan mengabaikan sektor pertanian sebagai tumpuannya. Lalu apakah masyarakat Bali sebaiknya kembali kepada budaya terdahulunya untuk bertumpu pada sektor pertanian?</p>

                                <div class="post-meta d-flex justify-content-between pt-3 border-top">
                                    <a href="mainpage/blogposts/single-page.php?slug=Esensi-Budaya-Bercocok-Tanam-Masyarakat-Bali-Sejak-Masa-Lampau-Hingga-Menjadi-Concern-Baru-di-Era-New-Normal" class="text-dark read">Baca Selanjutnya <i class="mdi mdi-chevron-right"></i></a>
                                </div>
                            </div>
                            </div><!--end post-->
                        </div><!--end col-->
                                    </div>
            <center>
            <a href="mainpage/blog-page.php" class="btn btn-primary mt-4" style="text-align:center;">Lihat Blog Lainnya</a>
            </center>
        </div>
    </div>
    <!-- END BLOG -->
    <section style="margin-bottom: 50px">
        <div class="container card">
                     <div id="calendar" class="col-centered p-5">
        </div>
    </section>
    <!-- JURNAL -->
    <section>
        <div class="container">
            <div class="row" style=" margin-bottom: 100px">
                <div class="col-lg-5 col-md-5 col-12">
                    <img class="image-jurnal" src="bem_images/jurnal.png" width="400px">
                </div>
                <div class="col-lg-7 col-md-7 col-12" style="margin-top: 50px">
                    <h2 class="display-4 museo">Jurnal Reparasi</h2>
                    <h4 class="museo">Volume 2</h4>
                    <p>Tak terasa, kepengurusan Kabinet Reparasi Cita Udayana telah berjalan selama lebih dari enam bulan. Begitu banyak hal terjadi selama setengah tahun ke belakang. Seperti tinta, beragam peristiwa itu menorehkan warnanya masing-masing. Dengan senang hati kami persembahkan "anak kedua" kami. Hari ini, Jurnal Reparasi Volume 2 sudah bisa dinikmati. Penasaran dengan isinya? Yuk baca Jurnal Reparasi sekarang!</p>
                    <a href="https://issuu.com/bem_udayana/docs/jurnal_20reparasi_20-_20volume_20ii" class="video-play-icon watch text-light mb-2 btn btn-pills btn-light mb-2">Baca Disini</a>
                </div>
            </div>
            
        </div>
    </section>
    <!-- END JURNAL -->

    <!-- PODCAST -->
    <section style="margin-bottom: 50px">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="display-4 museo">Udayana Podcast</h2>
                    <p style="margin-bottom: 30px">Sebuah persembahan dari BEM PM Udayana untuk kawan-kawan mahasiswa Udayana. Di sini kita akan membawakan topik maupun isu yang sedang hangat diperbincangkan di seputar dunia mahasiswa maupun yang sedang terjadi diantara kita secara santai. Selamat mendengarkan.</p>
                </div>
                <div class="col-12" style="margin-bottom: 50px">
                    <iframe src="https://open.spotify.com/embed-podcast/episode/6eip9z7yL5Inhx8FwuNaUy" width="100%" height="232" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
                </div>
            </div>
        </div>
    </section>
    <!-- END PODCAST -->

    <!-- SOSIAL -->
    <div class="position-relative">
        <div class="attach-icons-hero text-center py-5 py-sm-0">    
            <a href="https://www.instagram.com/bem_udayana/?hl=id"><img src="bem_images/sosial/instagram.png" class="img-fluid avatar avatar-small my-2 my-sm-0 mx-2 p-3 bg-white rounded-sosial shadow" data-toggle="tooltip" data-placement="top" title="Instagram" alt=""></a>
            <a href="https://twitter.com/bem_udayana"><img src="bem_images/sosial/twitter.png" class="img-fluid avatar avatar-small my-2 my-sm-0 mx-2 p-3 bg-white rounded-sosial shadow" data-toggle="tooltip" data-placement="top" title="Twitter" alt=""></a>
            <a href="https://www.youtube.com/channel/UCXb4WEhsHyKtMdqPaKJ4okQ"><img src="bem_images/sosial/youtube.png" class="img-fluid avatar avatar-small my-2 my-sm-0 mx-2 p-3 bg-white rounded-sosial shadow" data-toggle="tooltip" data-placement="top" title="Youtube" alt=""></a>
            <a href="https://open.spotify.com/show/4yP3a4QR1VZ2O1eKSrpNdb?si=MKF2hnCIQ8OQN7BYX2UoNA"><img src="bem_images/sosial/spotify.png" class="img-fluid avatar avatar-small my-2 my-sm-0 mx-2 p-3 bg-white rounded-sosial shadow" data-toggle="tooltip" data-placement="top" title="Spotify" alt=""></a>
        </div>
    </div>
    <!-- SOSIAL END -->
    
    <!-- Footer Start -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                    <a class="logo-footer" href="#">
                        <img src="bem_images/logo-light.png" height="40" alt="">
                    </a>
                    <p class="mt-1">"Bersama Ciptakan Karsa dalam Semangat Reparasi Cita untuk Udayana dan Indonesia"</p>
                </div>

                <div class="col-lg-4 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Sekretariat Kami :</h5>
                    <p>Jalan Dr. Goris No. 10, Student Center Lt. 2, Denpasar, Bali, Indonesia<p>
                </div>

                <div class="col-lg-4 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Kontak :</h5>
                    <ul class="list-unstyled footer-list mt-2">
                        <li><i data-feather="mail" class="fea icon-sm mr-2"></i><a href="mailto:contact@bemudayana.id" class="text-foot">contact@bemudayana.id</a></li>
                        <li><i data-feather="phone" class="fea icon-sm mr-2"></i><a href="tel:+6281338955721" class="text-foot">081 338 955 721</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <h5 class="text-light footer-head font-weight-normal">Sosial Media</h5>
                    <ul class="list-unstyled footer-list mt-2">
                        <ul class="list-unstyled social-icon social mb-0">
                            <li class="list-inline-item"><a href="https://www.instagram.com/bem_udayana/?hl=id" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://twitter.com/BEM_Udayana" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://www.youtube.com/channel/UCXb4WEhsHyKtMdqPaKJ4okQ" class="rounded"><i data-feather="youtube" class="fea icon-sm fea-social"></i></a></li>
                            <li class="list-inline-item"><a href="https://open.spotify.com/show/4yP3a4QR1VZ2O1eKSrpNdb?si=MKF2hnCIQ8OQN7BYX2UoNA" class="rounded"><i class="fa fa-spotify" class="fea icon-sm fea-social"></i></a></li>
                        </ul>
                    </ul>
                </div>
            </div>
        </div><!--end container-->
    </footer><!--end footer-->
    <!-- Footer End -->

    <!--Footer Bar-->
    <footer class="footer footer-bar">
        <div class="container text-center">
            <p class="mb-0" style="text-align: center; color: yellow;">© 2020 KOMINFO BEM PM UDAYANA</p>
        </div>
    </footer><!--end footer-->
    <!-- Footer Bar End -->

    <!-- Back to top -->
    <a href="#" class="back-to-top rounded text-center" id="back-to-top">
        <i class="mdi mdi-chevron-up d-block"></i>
    </a>
    <!-- Back to top -->

    <!-- Javascript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <script src="bem_js/jquery.min.js"></script>
    <script src="bem_js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <!-- Feather icon -->
    <script src="bem_js/feather.min.js"></script>

    <!-- Loader -->
    <script>
        $(document).ready(function(){
        $(".preloader").fadeOut();
        })
    </script>

    <!-- Magnific Popup -->
    <script src="bem_js/jquery.magnific-popup.min.js"></script>
    <script src="bem_js/magnific.init.js"></script>
    <script src="bem_js/isotope.js"></script>
    <script src="bem_js/portfolio.init.js"></script>

    <!-- Main Js -->
    <script src="bem_js/app.js"></script>

    <!-- Feather icon -->
    <script src="bem_js/feather.min.js"></script>

    <!-- Swiper -->
    <script src="bem_js/swiper.min.js"></script>
    <script src="bem_js/swiper.init.js"></script>

    <!--Counter-->
    <script src="bem_js/counter.init.js"></script>
     <script src="moment/moment.js"></script>
        <script src="fullcalendar/dist/fullcalendar.min.js"></script>
        <script>
  $(document).ready(function() {

    $('#calendar').fullCalendar({
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,basicWeek,basicDay',
        textColor: 'white'
      },

         eventLimit: true, // allow "more" link when too many events
            selectable: true,
            selectHelper: true,
      select: function(start, end) {

        $('#ModalAdd #start').val(moment(start).format('YYYY-MM-DD HH:mm:ss'));
        $('#ModalAdd #end').val(moment(end).format('YYYY-MM-DD HH:mm:ss'));
        $('#ModalAdd').modal('show');
      },
      eventRender: function(event, element) {
        element.bind('dblclick', function() {
          $('#ModalEdit #id').val(event.id);
          $('#ModalEdit #title').val(event.title);
          $('#ModalEdit #color').val(event.color);
          $('#ModalEdit #color').val(event.color);
          $('#ModalEdit').modal('show');
        });
      },
      eventDrop: function(event, delta, revertFunc) { // si changement de position

        edit(event);

      },
      eventResize: function(event, dayDelta, minuteDelta, revertFunc) { // si changement de longueur

        edit(event);

      },
      events: [
         {
            id: '72',
            title: 'Grand Opening Dies Natalis ke-58 Universitas Udayana',
            start: '2020-10-01',
            end: '2020-10-01',
            color: '#FF0000',
          },
         {
            id: '73',
            title: 'PMU Sesi 5',
            start: '2020-12-06',
            end: '2020-12-07',
            color: '#FF0000',
          },
         {
            id: '74',
            title: 'Udayana Charity Night',
            start: '2020-11-14',
            end: '2020-11-15',
            color: '#0071c5',
          },
         {
            id: '75',
            title: 'Sima Krama PM',
            start: '2020-12-05',
            end: '2020-12-06',
            color: '#008000',
          },
         {
            id: '78',
            title: 'Upgrading 1',
            start: '2021-03-19',
            end: '2021-03-21 23:59:00',
            color: '#FFD700',
          },
         {
            id: '80',
            title: 'SNMPTN',
            start: '2021-03-22',
            end: '2021-03-23',
            color: '#40E0D0',
          },
         {
            id: '81',
            title: 'FGD BEM PM',
            start: '2021-03-07',
            end: '2021-03-08',
            color: '#FFD700',
          },
         {
            id: '83',
            title: 'Student Day',
            start: '2021-08-23',
            end: '2021-08-25',
            color: '#FFD700',
          },
              ]
    });

    function edit(event) {
      start = event.start.format('YYYY-MM-DD HH:mm:ss');
      if (event.end) {
        end = event.end.format('YYYY-MM-DD HH:mm:ss');
      } else {
        end = start;
      }

      id = event.id;

      Event = [];
      Event[0] = id;
      Event[1] = start;
      Event[2] = end;

      $.ajax({
        url: 'editEventDate.php',
        type: "POST",
        data: {
          Event: Event
        },
        success: function(rep) {
          if (rep == 'OK') {
            alert('Saved');
          } else {
            alert('Could not be saved. try again.');
          }
        }
      });
    }

  });
</script>
</body>
</html>